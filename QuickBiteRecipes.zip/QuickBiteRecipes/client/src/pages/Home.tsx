import { Link } from "wouter";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { RecipeMock } from "@shared/schema";
import { recipes as mockRecipes } from "@/lib/recipes";
import RecipeList from "@/components/RecipeList";
import { useTranslations } from "@/hooks/use-translations";
import { useAuth } from "@/hooks/use-auth";

export default function Home() {
  const { t, language } = useTranslations();
  const { user } = useAuth();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Fetch recipes from API
  const {
    data: recipes,
    isLoading,
    error,
  } = useQuery<RecipeMock[]>({
    queryKey: ["/api/recipes/popular", language],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/recipes/popular?language=${language}&limit=8`);
        if (!response.ok) {
          throw new Error("Failed to fetch recipes");
        }
        const data = await response.json();
        return data;
      } catch (error) {
        console.error("Error fetching recipes:", error);
        throw error;
      }
    },
  });

  // Use mock recipes while we're building the backend integration
  const displayRecipes = recipes || mockRecipes;

  return (
    <div className="fade-in">
      {/* Hero section */}
      <section className="mb-16 text-center py-10 px-4 rounded-xl bg-gradient-to-r from-primary/5 to-secondary/5">
        <h1 className="text-4xl md:text-5xl font-bold mb-4 font-heading text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
          {t("home.title", "Discover Delicious Recipes")}
        </h1>
        <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
          {t("home.subtitle", "Find the perfect meal with ingredients you already have at home.")}
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link 
            href="/search"
            className="bg-primary hover:bg-primary/90 text-white font-bold py-3 px-6 rounded-lg shadow-md transition-all font-heading flex items-center justify-center"
          >
            <i className="ri-search-line mr-2"></i>
            {t("search.title", "Search by Ingredients")}
          </Link>
          
          {!user && (
            <Link 
              href="/auth"
              className="bg-white border border-primary hover:bg-primary/5 text-primary font-bold py-3 px-6 rounded-lg shadow-md transition-all font-heading flex items-center justify-center"
            >
              <i className="ri-user-add-line mr-2"></i>
              {t("auth.register", "Register")}
            </Link>
          )}
        </div>
      </section>

      {/* Popular recipes section */}
      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold font-heading">{t("home.popular_recipes", "Popular Recipes")}</h2>
          <Link 
            href="/search" 
            className="text-primary hover:text-primary/80 font-semibold text-sm flex items-center"
          >
            {t("home.view_all", "View All")}
            <i className="ri-arrow-right-line ml-1"></i>
          </Link>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="text-center py-12 text-gray-500">
            <p>{t("home.error_loading", "Error loading recipes. Please try again later.")}</p>
          </div>
        ) : (
          <RecipeList recipes={displayRecipes} />
        )}
      </section>

      {/* Features section */}
      {mounted && (
        <section className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <i className="ri-restaurant-line text-xl text-primary"></i>
            </div>
            <h3 className="text-xl font-bold mb-2 font-heading">{t("home.feature_1_title", "Multilingual Recipes")}</h3>
            <p className="text-gray-600">{t("home.feature_1_desc", "Browse recipes in Uzbek, English, and Russian")}</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center mb-4">
              <i className="ri-robot-line text-xl text-secondary"></i>
            </div>
            <h3 className="text-xl font-bold mb-2 font-heading">{t("home.feature_2_title", "Cooking Assistant")}</h3>
            <p className="text-gray-600">{t("home.feature_2_desc", "Get help with ingredients, substitutions, and cooking techniques")}</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <i className="ri-user-star-line text-xl text-primary"></i>
            </div>
            <h3 className="text-xl font-bold mb-2 font-heading">{t("home.feature_3_title", "Share & Earn Points")}</h3>
            <p className="text-gray-600">{t("home.feature_3_desc", "Share your own recipes and earn points when others rate them")}</p>
          </div>
        </section>
      )}
    </div>
  );
}
