import { Link, useParams } from "wouter";
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getRecipeById } from "@/lib/recipes";
import { RecipeMock, RatingMock } from "@shared/schema";
import StarRating from "@/components/StarRating";
import { askCookingAssistant } from "@/lib/aiAssistant";
import { useTranslations } from "@/hooks/use-translations";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function RecipeDetail() {
  const { id } = useParams();
  const recipeId = id ? parseInt(id) : 0;
  const { t } = useTranslations();
  const { user } = useAuth();
  const { toast } = useToast();

  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [userQuestion, setUserQuestion] = useState("");
  const [assistantResponse, setAssistantResponse] = useState("");
  const [isAskingQuestion, setIsAskingQuestion] = useState(false);
  const [userRating, setUserRating] = useState<number>(0);
  const [userReview, setUserReview] = useState("");

  // Get recipe data from API or mock data as fallback
  const {
    data: recipe,
    isLoading: isLoadingRecipe,
    error: recipeError
  } = useQuery<RecipeMock>({
    queryKey: ["/api/recipes", recipeId],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/recipes/${recipeId}`);
        if (!response.ok) {
          // If the API is not available yet, use mock data
          const mockRecipe = getRecipeById(recipeId);
          if (!mockRecipe) throw new Error("Recipe not found");
          return mockRecipe;
        }
        return await response.json();
      } catch (error) {
        console.error("Error fetching recipe:", error);
        // Use mock data as fallback
        const mockRecipe = getRecipeById(recipeId);
        if (!mockRecipe) throw new Error("Recipe not found");
        return mockRecipe;
      }
    },
    enabled: !!recipeId,
  });

  // Get user's ratings for this recipe (to check if they can leave more reviews)
  const { data: userRatings = [] } = useQuery<RatingMock[]>({
    queryKey: ["/api/ratings/user", recipeId],
    queryFn: async () => {
      if (!user) return [];
      try {
        const response = await fetch(`/api/ratings/user/${recipeId}`);
        if (!response.ok) return [];
        return await response.json();
      } catch (error) {
        console.error("Error fetching user ratings:", error);
        return [];
      }
    },
    enabled: !!user && !!recipeId,
  });

  // Submit rating mutation
  const submitRatingMutation = useMutation({
    mutationFn: async (ratingData: Omit<RatingMock, "id" | "date" | "userName">) => {
      // If API integration is not ready, use mock implementation
      if (!user) throw new Error("You must be logged in to rate recipes");
      
      // Try the API first
      try {
        const response = await apiRequest("POST", "/api/ratings", {
          ...ratingData,
          userId: user.id,
        });
        
        if (!response.ok) {
          throw new Error("Failed to submit review");
        }
        
        return await response.json();
      } catch (error) {
        console.error("Error submitting rating:", error);
        throw error;
      }
    },
    onSuccess: () => {
      toast({
        title: t("recipe.review_success", "Review submitted!"),
        description: t(
          "recipe.review_success_desc",
          "Thank you for sharing your experience with this recipe."
        ),
      });
      
      // Reset form
      setUserRating(0);
      setUserReview("");
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/recipes", recipeId] });
      queryClient.invalidateQueries({ queryKey: ["/api/ratings/user", recipeId] });
    },
    onError: (error: Error) => {
      toast({
        title: t("recipe.review_error", "Error submitting review"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const handleSubmitReview = () => {
    if (!recipe || !userRating) return;
    
    // Submit the rating
    submitRatingMutation.mutate({
      recipeId: recipe.id,
      rating: userRating,
      comment: userReview,
    });
  };

  // Scroll to top when loading a new recipe
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  // AI Assistant functions
  const toggleAIAssistant = () => {
    setShowAIAssistant(!showAIAssistant);
    setAssistantResponse(""); // Clear previous responses
  };

  const handleAskQuestion = async () => {
    if (!userQuestion.trim() || !recipe) return;
    
    setIsAskingQuestion(true);
    
    try {
      // Use the AI cooking assistant
      const response = await askCookingAssistant(userQuestion, recipe);
      setAssistantResponse(response);
    } catch (error) {
      console.error("Error with cooking assistant:", error);
      setAssistantResponse(t(
        "recipe.assistant_error",
        "Sorry, I couldn't process your question. Could you try asking something else about the recipe?"
      ));
    } finally {
      setIsAskingQuestion(false);
      setUserQuestion(""); // Clear the question field after asking
    }
  };

  // Loading state
  if (isLoadingRecipe) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Error state
  if (recipeError || !recipe) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">{t("recipe.not_found", "Recipe not found")}</h2>
          <p className="text-gray-600 mb-4">{t("recipe.not_found_desc", "The recipe you're looking for doesn't exist.")}</p>
          <Link 
            href="/"
            className="text-primary hover:text-primary/80 font-semibold flex items-center justify-center"
          >
            <i className="ri-arrow-left-line mr-1"></i>
            {t("recipe.back_home", "Back to Home")}
          </Link>
        </div>
      </div>
    );
  }

  // Check if user can leave a review (maximum 2 reviews per recipe)
  const canLeaveReview = user && userRatings.length < 2;
  
  // Get reason for not being able to review
  const getReviewDisabledReason = () => {
    if (!user) return t("recipe.login_to_review", "Please login to leave a review");
    if (userRatings.length >= 2) return t("recipe.max_reviews", "You've already submitted the maximum number of reviews (2) for this recipe");
    return "";
  };

  return (
    <div className="fade-in">
      <Link 
        href="/"
        className="mb-6 text-primary hover:text-primary/80 font-semibold flex items-center"
      >
        <i className="ri-arrow-left-line mr-1"></i>
        {t("recipe.back_home", "Back to Home")}
      </Link>

      <div className="bg-white rounded-xl overflow-hidden shadow-md p-6 md:p-8 mb-8">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="md:w-1/2">
            <img 
              src={recipe.image} 
              alt={recipe.title} 
              className="w-full h-64 md:h-80 object-cover rounded-lg shadow-md"
            />
            <div className="mt-4 flex justify-between items-center">
              <div>
                <StarRating rating={recipe.averageRating || 0} size="md" />
                <span className="text-sm text-gray-600 ml-2">
                  {recipe.ratings.length} {recipe.ratings.length === 1 
                    ? t("recipe.review_single", "review") 
                    : t("recipe.review_plural", "reviews")}
                </span>
              </div>
              
              <button 
                onClick={toggleAIAssistant}
                className="bg-secondary hover:bg-secondary/90 text-white py-2 px-4 rounded-md flex items-center text-sm"
              >
                <i className="ri-robot-line mr-1"></i>
                {showAIAssistant 
                  ? t("recipe.hide_assistant", "Hide Assistant") 
                  : t("recipe.cooking_assistant", "Cooking Assistant")}
              </button>
            </div>
          </div>
          
          <div className="md:w-1/2">
            <h1 className="text-3xl font-bold mb-4 font-heading">{recipe.title}</h1>
            
            <div className="flex flex-wrap gap-2 mb-6">
              {recipe.tags.map((tag, index) => (
                <span key={index} className="inline-block bg-secondary/10 text-secondary px-2 py-1 rounded text-xs">
                  {tag}
                </span>
              ))}
            </div>
            
            <div className="flex items-center mb-6 text-sm text-gray-600">
              <div className="flex items-center mr-4">
                <i className="ri-time-line mr-1"></i>
                <span>{recipe.time}</span>
              </div>
              <div className="flex items-center mr-4">
                <i className="ri-restaurant-line mr-1"></i>
                <span>{recipe.servings} {t("recipe.servings", "servings")}</span>
              </div>
              <div className="flex items-center">
                <i className="ri-fire-line mr-1"></i>
                <span>{recipe.calories} {t("recipe.calories", "cal")}</span>
              </div>
            </div>
            
            <h2 className="text-xl font-bold mb-3 font-heading">{t("recipe.ingredients", "Ingredients")}</h2>
            <ul className="mb-6 space-y-2">
              {recipe.ingredients.map((ingredient, index) => (
                <li key={index} className="flex items-start">
                  <i className="ri-checkbox-blank-circle-line text-primary mr-2 mt-1"></i>
                  <span>{ingredient}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* AI Cooking Assistant */}
        {showAIAssistant && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <h3 className="text-lg font-semibold mb-3 flex items-center">
              <i className="ri-robot-line mr-2 text-secondary"></i>
              {t("recipe.cooking_assistant", "Cooking Assistant")}
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              {t("recipe.assistant_desc", "Having trouble with the recipe? Ask our AI cooking assistant for help!")}
            </p>
            
            <div className="flex gap-2">
              <input
                type="text"
                value={userQuestion}
                onChange={(e) => setUserQuestion(e.target.value)}
                placeholder={t("recipe.ask_question", "Ask a question about this recipe...")}
                className="flex-1 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <button 
                onClick={handleAskQuestion}
                disabled={isAskingQuestion || !userQuestion.trim()}
                className="bg-primary hover:bg-primary/90 text-white py-2 px-4 rounded-md disabled:opacity-50"
              >
                {isAskingQuestion 
                  ? t("recipe.asking", "Asking...") 
                  : t("recipe.ask", "Ask")}
              </button>
            </div>
            
            {assistantResponse && (
              <div className="mt-4 p-3 bg-white rounded-md border border-gray-200">
                <div className="flex items-start">
                  <i className="ri-robot-line mr-2 text-secondary mt-1"></i>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-gray-800 mb-1">{t("recipe.ai_assistant", "AI Assistant")}</p>
                    <p className="text-sm text-gray-700">{assistantResponse}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
        
        <div className="mt-8">
          <h2 className="text-xl font-bold mb-4 font-heading">{t("recipe.instructions", "Instructions")}</h2>
          <ol className="space-y-4">
            {recipe.instructions.map((instruction, index) => (
              <li key={index} className="flex">
                <span className="bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-3 flex-shrink-0">
                  {index + 1}
                </span>
                <p>{instruction}</p>
              </li>
            ))}
          </ol>
        </div>
      </div>
      
      {/* Reviews section */}
      <div className="bg-white rounded-xl overflow-hidden shadow-md p-6 md:p-8 mb-8">
        <h2 className="text-xl font-bold mb-6 font-heading">{t("recipe.reviews", "Reviews")}</h2>
        
        {recipe.ratings.length > 0 ? (
          <div className="space-y-4 mb-8">
            {recipe.ratings.map((rating) => (
              <div key={rating.id} className="border-b pb-4">
                <div className="flex justify-between items-center mb-2">
                  <div className="font-semibold">{rating.userName}</div>
                  <div className="text-sm text-gray-500">{rating.date}</div>
                </div>
                <StarRating rating={rating.rating} size="sm" />
                {rating.comment && (
                  <p className="mt-2 text-gray-700">{rating.comment}</p>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 mb-6">{t("recipe.no_reviews", "No reviews yet. Be the first to rate this recipe!")}</p>
        )}
        
        {/* Add review form */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-semibold mb-4">{t("recipe.leave_review", "Leave a Review")}</h3>
          
          {!canLeaveReview ? (
            <div className="p-3 bg-gray-100 rounded-md text-gray-600">
              {getReviewDisabledReason()}
              {!user && (
                <Link href="/auth" className="block mt-2 text-primary hover:underline">
                  {t("recipe.login_now", "Login now")}
                </Link>
              )}
            </div>
          ) : (
            <div className="space-y-4">              
              <div>
                <label className="block text-sm font-medium mb-1">{t("recipe.your_rating", "Your Rating")}</label>
                <StarRating 
                  rating={userRating} 
                  interactive={true} 
                  onRatingChange={setUserRating}
                  size="md"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">{t("recipe.your_review", "Your Review")} ({t("recipe.optional", "optional")})</label>
                <textarea
                  value={userReview}
                  onChange={(e) => setUserReview(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  rows={3}
                  placeholder={t("recipe.review_placeholder", "Share your experience with this recipe")}
                />
              </div>
              
              <button
                onClick={handleSubmitReview}
                disabled={submitRatingMutation.isPending || !userRating}
                className="bg-primary hover:bg-primary/90 text-white py-2 px-4 rounded-md disabled:opacity-50"
              >
                {submitRatingMutation.isPending 
                  ? t("recipe.submitting", "Submitting...") 
                  : t("recipe.submit_review", "Submit Review")}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
