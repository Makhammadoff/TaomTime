import { useState, useEffect } from "react";
import IngredientSearch from "@/components/IngredientSearch";
import SelectedIngredients from "@/components/SelectedIngredients";
import RecipeResults from "@/components/RecipeResults";
import { getMatchingRecipes } from "@/lib/recipes";
import { Recipe } from "@shared/schema";

export default function IngredientSearchPage() {
  const [selectedIngredients, setSelectedIngredients] = useState<string[]>([]);
  const [matchingRecipes, setMatchingRecipes] = useState<Recipe[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  // Add an ingredient to the selected list
  const handleAddIngredient = (ingredient: string) => {
    const ingredientLower = ingredient.toLowerCase();
    
    if (selectedIngredients.some(ing => ing.toLowerCase() === ingredientLower)) {
      return;
    }
    
    setSelectedIngredients(prev => [...prev, ingredient]);
  };
  
  // Remove an ingredient from the selected list
  const handleRemoveIngredient = (ingredient: string) => {
    setSelectedIngredients(prev => 
      prev.filter(ing => ing.toLowerCase() !== ingredient.toLowerCase())
    );
  };
  
  // Find recipes that match the selected ingredients
  const handleFindRecipes = () => {
    const recipes = getMatchingRecipes(selectedIngredients);
    setMatchingRecipes(recipes);
    setHasSearched(true);
  };

  // Update recipes when selectedIngredients changes if we've already searched
  useEffect(() => {
    if (hasSearched) {
      const recipes = getMatchingRecipes(selectedIngredients);
      setMatchingRecipes(recipes);
    }
  }, [selectedIngredients, hasSearched]);

  return (
    <div className="fade-in">
      <h1 className="text-3xl font-bold mb-6 font-heading">Find Recipes by Ingredients</h1>
      <p className="text-lg text-gray-600 mb-8">Enter ingredients you have, and we'll show you matching recipes.</p>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-md p-6 sticky top-4">
            <h2 className="text-xl font-bold mb-4 font-heading">Ingredients</h2>
            
            {/* Ingredient Search Component */}
            <IngredientSearch 
              selectedIngredients={selectedIngredients}
              onAddIngredient={handleAddIngredient}
            />
            
            {/* Selected Ingredients Component */}
            <SelectedIngredients
              selectedIngredients={selectedIngredients}
              onRemoveIngredient={handleRemoveIngredient}
              onFindRecipes={handleFindRecipes}
            />
          </div>
        </div>
        
        <div className="lg:col-span-2">
          {/* Recipe Results Component */}
          <RecipeResults 
            recipes={matchingRecipes}
            selectedIngredients={selectedIngredients}
          />
        </div>
      </div>
    </div>
  );
}
