import { RecipeMock } from '@shared/schema';

// Common cooking question patterns and their responses
const commonQuestions = [
  {
    patterns: ['substitute', 'replace', 'instead of', 'alternative'],
    getResponse: (ingredient: string, recipe: RecipeMock) => {
      const commonSubstitutes: Record<string, string> = {
        'avocado': 'You can substitute avocado with mashed banana or Greek yogurt in some recipes, though the flavor will be different.',
        'butter': 'You can substitute butter with olive oil, coconut oil, or applesauce depending on the recipe.',
        'eggs': 'For eggs, you can use a flax egg (1 tbsp ground flaxseed + 3 tbsp water) or 1/4 cup applesauce per egg.',
        'milk': 'Milk can be substituted with almond milk, soy milk, oat milk, or coconut milk.',
        'cream': 'For cream, try coconut cream or cashew cream as dairy-free alternatives.',
        'flour': 'All-purpose flour can often be replaced with almond flour, coconut flour, or a gluten-free blend, but you may need to adjust quantities.',
        'sugar': 'You can replace sugar with honey, maple syrup, or stevia (in smaller amounts).',
        'sour cream': 'Greek yogurt is a great substitute for sour cream.',
        'oil': 'Applesauce can replace oil in many baking recipes for a lower-fat option.',
        'garlic': 'If you don\'t have fresh garlic, use 1/8 tsp garlic powder for each clove.',
        'onion': 'Shallots, leeks, or onion powder can replace onions if needed.',
        'tomatoes': 'Red bell peppers can sometimes substitute for tomatoes if you\'re allergic.',
        'rice': 'Cauliflower rice, quinoa, or barley can work as rice alternatives.',
        'pasta': 'Zucchini noodles, spaghetti squash, or chickpea pasta are good pasta alternatives.',
        'beef': 'Portobello mushrooms, lentils, or plant-based meat alternatives can substitute for beef.',
        'chicken': 'Tofu, chickpeas, or jackfruit can work as chicken alternatives in many recipes.',
        'cheese': 'Nutritional yeast provides a cheesy flavor, or use plant-based cheese alternatives.',
        'lemon': 'Lime or vinegar can often substitute for lemon juice.'
      };

      // Find the ingredient being asked about
      let foundIngredient = '';
      for (const key of Object.keys(commonSubstitutes)) {
        if (ingredient.toLowerCase().includes(key.toLowerCase())) {
          foundIngredient = key;
          break;
        }
      }

      if (foundIngredient) {
        return commonSubstitutes[foundIngredient];
      } else {
        return `I don't have specific substitution information for ${ingredient}. As a general rule, try to substitute with ingredients that have similar properties (texture, fat content, sweetness, etc).`;
      }
    }
  },
  {
    patterns: ['how long', 'time', 'minutes', 'hours', 'cook time', 'bake time'],
    getResponse: (question: string, recipe: RecipeMock) => {
      return `The total cooking time for ${recipe.title} is ${recipe.time}. Make sure to follow each step carefully, and remember that cooking times can vary based on your equipment.`;
    }
  },
  {
    patterns: ['calories', 'nutrition', 'healthy', 'fat', 'protein', 'carbs', 'carbohydrates'],
    getResponse: (question: string, recipe: RecipeMock) => {
      return `${recipe.title} contains approximately ${recipe.calories} calories per serving. This recipe serves ${recipe.servings} people. For detailed nutritional information including protein, fat, and carbohydrates, you would need to calculate based on the specific ingredients and their quantities.`;
    }
  },
  {
    patterns: ['freeze', 'freezer', 'make ahead', 'store', 'storage', 'keep'],
    getResponse: (question: string, recipe: RecipeMock) => {
      const generalStorageInfo = `Most prepared foods can be stored in the refrigerator for 3-4 days in an airtight container.`;
      
      if (recipe.title.toLowerCase().includes('salad') || recipe.tags.some(tag => tag.toLowerCase() === 'salad')) {
        return `Salads like ${recipe.title} are typically best enjoyed fresh. If you need to store it, keep the dressing separate and add it just before serving. ${generalStorageInfo}`;
      } else if (recipe.tags.some(tag => tag.toLowerCase().includes('soup') || tag.toLowerCase().includes('stew'))) {
        return `Soups and stews like ${recipe.title} generally freeze well for up to 3 months. ${generalStorageInfo}`;
      } else if (recipe.tags.some(tag => tag.toLowerCase().includes('pasta'))) {
        return `Pasta dishes like ${recipe.title} can be refrigerated but may dry out. Add a little liquid when reheating. ${generalStorageInfo}`;
      } else if (recipe.tags.some(tag => tag.toLowerCase().includes('bake') || tag.toLowerCase().includes('dessert'))) {
        return `Baked goods like ${recipe.title} can often be frozen for up to 1 month. Wrap well to prevent freezer burn. ${generalStorageInfo}`;
      } else {
        return `${recipe.title} can likely be stored in the refrigerator for 3-4 days. For freezing, separate components that freeze well from those that don't for best results.`;
      }
    }
  },
  {
    patterns: ['double', 'half', 'size', 'portion', 'scale', 'servings'],
    getResponse: (question: string, recipe: RecipeMock) => {
      if (question.toLowerCase().includes('double') || question.toLowerCase().includes('more')) {
        return `To double ${recipe.title}, multiply all ingredient quantities by 2. Cooking time might need a slight increase, especially for baked goods or larger volumes. Keep an eye on it as it cooks.`;
      } else if (question.toLowerCase().includes('half') || question.toLowerCase().includes('less')) {
        return `To halve ${recipe.title}, divide all ingredient quantities by 2. Cooking time might need to be reduced slightly, so check for doneness earlier than the recipe suggests.`;
      } else {
        return `This recipe for ${recipe.title} makes ${recipe.servings} servings. To scale it up or down, multiply or divide all ingredient quantities by the same factor, but be aware that cooking times may need adjustment.`;
      }
    }
  },
  {
    patterns: ['spicy', 'heat', 'hot', 'mild', 'spice'],
    getResponse: (question: string, recipe: RecipeMock) => {
      if (question.toLowerCase().includes('spic') || question.toLowerCase().includes('hot')) {
        return `To make ${recipe.title} spicier, you could add red pepper flakes, diced jalapeño, cayenne pepper, or hot sauce according to your heat preference. Start with a small amount and taste as you go.`;
      } else if (question.toLowerCase().includes('mild') || question.toLowerCase().includes('less spicy')) {
        return `To make ${recipe.title} milder, reduce or omit any hot spices like cayenne or chili powder. You can also balance heat with dairy (like sour cream or yogurt) or sweetness (like a touch of honey).`;
      } else {
        return `${recipe.title} can be adjusted to your preferred spice level. For more heat, add red pepper flakes or hot sauce. For less heat, reduce spicy ingredients and add more of the mild base ingredients.`;
      }
    }
  },
  {
    patterns: ['vegan', 'vegetarian', 'dairy-free', 'gluten-free', 'allergy'],
    getResponse: (question: string, recipe: RecipeMock) => {
      let response = '';
      
      if (question.toLowerCase().includes('vegan')) {
        if (recipe.tags.some(tag => tag.toLowerCase() === 'vegan')) {
          response = `Great news! ${recipe.title} is already vegan.`;
        } else {
          response = `To make ${recipe.title} vegan, you would need to substitute any animal products. `;
          if (recipe.ingredients.some(ing => ing.toLowerCase().includes('meat') || ing.toLowerCase().includes('chicken') || ing.toLowerCase().includes('beef'))) {
            response += `Replace meat with tofu, tempeh, or legumes. `;
          }
          if (recipe.ingredients.some(ing => ing.toLowerCase().includes('milk') || ing.toLowerCase().includes('cream'))) {
            response += `Substitute dairy milk with plant-based alternatives like almond or oat milk. `;
          }
          if (recipe.ingredients.some(ing => ing.toLowerCase().includes('cheese'))) {
            response += `Use vegan cheese or nutritional yeast for cheesy flavor. `;
          }
          if (recipe.ingredients.some(ing => ing.toLowerCase().includes('egg'))) {
            response += `Replace eggs with flax eggs (1 tbsp ground flaxseed + 3 tbsp water per egg) or other egg replacers. `;
          }
        }
      } else if (question.toLowerCase().includes('vegetarian')) {
        if (recipe.tags.some(tag => tag.toLowerCase() === 'vegetarian') || recipe.tags.some(tag => tag.toLowerCase() === 'vegan')) {
          response = `Good news! ${recipe.title} is already vegetarian.`;
        } else {
          response = `To make ${recipe.title} vegetarian, you would need to substitute any meat. `;
          if (recipe.ingredients.some(ing => ing.toLowerCase().includes('meat') || ing.toLowerCase().includes('chicken') || ing.toLowerCase().includes('beef'))) {
            response += `Replace meat with plant-based proteins like tofu, tempeh, or legumes, or with hearty vegetables like mushrooms or eggplant. `;
          }
        }
      } else if (question.toLowerCase().includes('gluten')) {
        response = `To make ${recipe.title} gluten-free, `;
        if (recipe.ingredients.some(ing => ing.toLowerCase().includes('flour'))) {
          response += `replace regular flour with a gluten-free blend. `;
        }
        if (recipe.ingredients.some(ing => ing.toLowerCase().includes('pasta'))) {
          response += `use gluten-free pasta. `;
        }
        if (recipe.ingredients.some(ing => ing.toLowerCase().includes('bread'))) {
          response += `substitute with gluten-free bread. `;
        }
        if (recipe.ingredients.some(ing => ing.toLowerCase().includes('soy sauce'))) {
          response += `replace soy sauce with tamari or coconut aminos. `;
        }
        response += `Also be careful with processed ingredients that might contain hidden gluten.`;
      } else if (question.toLowerCase().includes('dairy')) {
        response = `To make ${recipe.title} dairy-free, `;
        if (recipe.ingredients.some(ing => ing.toLowerCase().includes('milk'))) {
          response += `substitute milk with plant-based alternatives like almond, soy, or oat milk. `;
        }
        if (recipe.ingredients.some(ing => ing.toLowerCase().includes('butter'))) {
          response += `replace butter with plant-based butter, coconut oil, or olive oil. `;
        }
        if (recipe.ingredients.some(ing => ing.toLowerCase().includes('cheese'))) {
          response += `use dairy-free cheese alternatives or nutritional yeast for cheesy flavor. `;
        }
        if (recipe.ingredients.some(ing => ing.toLowerCase().includes('cream'))) {
          response += `substitute cream with coconut cream or cashew cream. `;
        }
      } else {
        response = `For dietary adjustments to ${recipe.title}, identify the specific ingredients you need to avoid and find appropriate substitutes. Common allergens like nuts, dairy, gluten, and eggs can often be replaced with alternative ingredients.`;
      }
      
      return response;
    }
  }
];

// General fallback responses that can be used when no specific pattern matches
const fallbackResponses = [
  (recipe: RecipeMock) => `I don't have specific information about that aspect of ${recipe.title}. Would you like to know about cooking time, ingredient substitutions, or dietary adjustments instead?`,
  (recipe: RecipeMock) => `That's a good question about ${recipe.title}. You might find helpful information by checking cooking websites or forums for similar recipes.`,
  (recipe: RecipeMock) => `For ${recipe.title}, I recommend following the recipe instructions carefully. Is there a specific step or ingredient you're concerned about?`,
  (recipe: RecipeMock) => `I'm not able to answer that specific question about ${recipe.title}. Would you like information about ingredient substitutions or cooking times instead?`,
  (recipe: RecipeMock) => `I don't have that information for ${recipe.title}. For cooking techniques, following a video tutorial might be helpful for visual guidance.`
];

// Get ingredients mentioned in the question
function getIngredientFromQuestion(question: string, recipe: RecipeMock): string {
  const lowerQuestion = question.toLowerCase();
  let foundIngredient = '';
  
  // Check recipe ingredients
  for (const ingredient of recipe.ingredientList) {
    if (lowerQuestion.includes(ingredient.toLowerCase())) {
      foundIngredient = ingredient;
      break;
    }
  }
  
  // Check common ingredients if none found in recipe
  if (!foundIngredient) {
    const commonIngredients = [
      'flour', 'sugar', 'eggs', 'butter', 'milk', 'oil', 'salt', 
      'pepper', 'garlic', 'onion', 'chicken', 'beef', 'pork', 'fish',
      'rice', 'pasta', 'cheese', 'yogurt', 'cream', 'vegetables', 'fruit'
    ];
    
    for (const ingredient of commonIngredients) {
      if (lowerQuestion.includes(ingredient)) {
        foundIngredient = ingredient;
        break;
      }
    }
  }
  
  return foundIngredient || 'ingredients';
}

// Main function to get responses for cooking questions
export function getLocalCookingAssistantResponse(question: string, recipe: RecipeMock): string {
  const lowerQuestion = question.toLowerCase();
  
  // Check for matching patterns from common questions
  for (const commonQuestion of commonQuestions) {
    if (commonQuestion.patterns.some(pattern => lowerQuestion.includes(pattern))) {
      const ingredient = getIngredientFromQuestion(question, recipe);
      return commonQuestion.getResponse(ingredient || question, recipe);
    }
  }
  
  // If no specific pattern matches, use a fallback response
  const randomFallback = fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
  return randomFallback(recipe);
}