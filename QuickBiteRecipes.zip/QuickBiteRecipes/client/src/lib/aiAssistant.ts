import { getLocalCookingAssistantResponse } from "@/lib/localCookingAssistant";
import { RecipeMock } from "@shared/schema";

// We'll always try to use the server-side OpenAI implementation
// and only fall back to local responses if the server returns an error

/**
 * Ask the cooking assistant a question about a recipe
 * 
 * @param question - User's question about the recipe
 * @param recipe - The recipe to ask about
 * @returns Promise with the assistant's response
 */
export async function askCookingAssistant(question: string, recipe: RecipeMock): Promise<string> {
  try {
    // OpenAI API call
    const response = await fetch("/api/ai/cooking-assistant", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        question,
        recipeId: recipe.id,
      }),
    });
    
    if (!response.ok) {
      throw new Error("Failed to get response from AI Cooking Assistant");
    }
    
    const data = await response.json();
    return data.answer;
  } catch (error) {
    console.error("Error with AI Cooking Assistant:", error);
    
    // Fall back to local assistant if API fails
    return getLocalCookingAssistantResponse(question, recipe);
  }
}