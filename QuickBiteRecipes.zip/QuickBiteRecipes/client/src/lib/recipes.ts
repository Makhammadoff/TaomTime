import { RecipeMock, Ingredient, RatingMock } from "@shared/schema";

// Helper function to calculate average rating
export function calculateAverageRating(ratings: RatingMock[]): number {
  if (ratings.length === 0) return 0;
  const sum = ratings.reduce((total, rating) => total + rating.rating, 0);
  return parseFloat((sum / ratings.length).toFixed(1));
}

// Pre-defined recipe data
export const recipes: RecipeMock[] = [
  {
    id: 1,
    title: "Avocado Salad",
    image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c",
    description: "A fresh and healthy salad with avocado, tomatoes, and feta cheese.",
    time: "20 min",
    servings: 2,
    calories: 320,
    tags: ["Vegetarian", "Healthy", "Easy"],
    ingredients: [
      "2 ripe avocados, diced",
      "1 cup cherry tomatoes, halved",
      "1/2 red onion, thinly sliced",
      "1/4 cup feta cheese, crumbled",
      "2 tbsp olive oil",
      "1 tbsp lemon juice",
      "Salt and pepper to taste"
    ],
    ingredientList: ["avocado", "tomato", "onion", "cheese", "olive oil", "lemon"],
    instructions: [
      "In a large bowl, combine the diced avocados, halved cherry tomatoes, and sliced red onion.",
      "In a small bowl, whisk together the olive oil, lemon juice, salt, and pepper to make the dressing.",
      "Pour the dressing over the salad and gently toss to combine.",
      "Sprinkle the crumbled feta cheese over the top.",
      "Serve immediately or refrigerate for up to 30 minutes before serving."
    ],
    ratings: [
      {
        id: 1,
        recipeId: 1,
        userName: "Alex",
        rating: 5,
        comment: "So fresh and delicious!",
        date: "2025-04-15"
      },
      {
        id: 2,
        recipeId: 1,
        userName: "Jamie",
        rating: 4,
        comment: "Great combination of flavors.",
        date: "2025-04-20"
      }
    ],
    averageRating: 4.5
  },
  {
    id: 2,
    title: "Spaghetti Carbonara",
    image: "https://images.unsplash.com/photo-1551183053-bf91a1d81141",
    description: "Rich and creamy pasta dish with eggs, cheese, and bacon.",
    time: "30 min",
    servings: 4,
    calories: 550,
    tags: ["Italian", "Pasta", "Dinner"],
    ingredients: [
      "1 lb spaghetti",
      "8 oz pancetta or bacon, diced",
      "4 large eggs",
      "1 cup Parmesan cheese, grated",
      "4 garlic cloves, minced",
      "Salt and black pepper to taste",
      "Fresh parsley, chopped (for garnish)"
    ],
    ingredientList: ["pasta", "bacon", "eggs", "cheese", "garlic"],
    instructions: [
      "Cook spaghetti according to package instructions until al dente. Reserve 1 cup of pasta water before draining.",
      "While pasta is cooking, in a large skillet, cook the diced pancetta or bacon until crispy. Add minced garlic and cook for 1 minute more.",
      "In a bowl, whisk together eggs, grated Parmesan, and black pepper.",
      "Add the drained hot pasta to the skillet with the pancetta and toss to combine.",
      "Remove from heat and quickly pour in the egg mixture, stirring constantly to create a creamy sauce. Add reserved pasta water as needed.",
      "Season with salt and pepper to taste, and garnish with chopped parsley before serving."
    ],
    ratings: [
      {
        id: 3,
        recipeId: 2,
        userName: "Sam",
        rating: 5,
        comment: "Authentic Italian taste! Just like my nonna used to make.",
        date: "2025-04-10"
      },
      {
        id: 4,
        recipeId: 2,
        userName: "Taylor",
        rating: 5,
        comment: "Perfect balance of flavors. A family favorite now!",
        date: "2025-04-22"
      },
      {
        id: 5,
        recipeId: 2,
        userName: "Jordan",
        rating: 4,
        comment: "Delicious, but I used less garlic than recommended.",
        date: "2025-04-18"
      }
    ],
    averageRating: 4.7
  },
  {
    id: 3,
    title: "Margherita Pizza",
    image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38",
    description: "Classic Italian pizza with fresh mozzarella, tomatoes, and basil.",
    time: "45 min",
    servings: 4,
    calories: 450,
    tags: ["Italian", "Pizza", "Dinner"],
    ingredients: [
      "1 pizza dough (store-bought or homemade)",
      "1/2 cup tomato sauce",
      "8 oz fresh mozzarella cheese, sliced",
      "2 tomatoes, thinly sliced",
      "Fresh basil leaves",
      "2 tbsp olive oil",
      "Salt and pepper to taste"
    ],
    ingredientList: ["dough", "tomato", "cheese", "basil", "olive oil"],
    instructions: [
      "Preheat oven to 475°F (245°C). If using a pizza stone, preheat it in the oven.",
      "Roll out the pizza dough on a floured surface to your desired thickness.",
      "Spread tomato sauce evenly over the dough, leaving a small border for the crust.",
      "Arrange mozzarella slices and tomato slices on top.",
      "Drizzle with olive oil and season with salt and pepper.",
      "Bake for 10-12 minutes or until the crust is golden and the cheese is bubbling.",
      "Remove from oven and top with fresh basil leaves before serving."
    ],
    ratings: [
      {
        id: 6,
        recipeId: 3,
        userName: "Riley",
        rating: 5,
        comment: "Simple but amazing. Quality ingredients make all the difference!",
        date: "2025-04-05"
      },
      {
        id: 7,
        recipeId: 3,
        userName: "Casey",
        rating: 3,
        comment: "Good, but I prefer more toppings on my pizza.",
        date: "2025-04-12"
      }
    ],
    averageRating: 4.0
  },
  {
    id: 4,
    title: "Berry Smoothie Bowl",
    image: "https://images.unsplash.com/photo-1515543237350-b3eea1ec8082",
    description: "Nutrient-packed breakfast bowl with mixed berries and toppings.",
    time: "10 min",
    servings: 1,
    calories: 280,
    tags: ["Breakfast", "Healthy", "Vegan"],
    ingredients: [
      "1 frozen banana",
      "1 cup mixed frozen berries (strawberries, blueberries, raspberries)",
      "1/4 cup almond milk",
      "1 tbsp honey or maple syrup (optional)",
      "Toppings: sliced fresh fruit, granola, chia seeds, coconut flakes"
    ],
    ingredientList: ["banana", "berries", "almond milk", "honey", "fruit", "granola"],
    instructions: [
      "In a blender, combine frozen banana, mixed berries, almond milk, and sweetener if using.",
      "Blend until smooth and creamy. The mixture should be thicker than a regular smoothie.",
      "Pour into a bowl.",
      "Top with your choice of sliced fresh fruit, granola, chia seeds, and coconut flakes.",
      "Serve immediately."
    ],
    ratings: [
      {
        id: 8,
        recipeId: 4,
        userName: "Morgan",
        rating: 5,
        comment: "So refreshing and healthy! I make this several times a week.",
        date: "2025-04-08"
      },
      {
        id: 9,
        recipeId: 4,
        userName: "Robin",
        rating: 4,
        comment: "Delicious! I added a scoop of protein powder for extra nutrition.",
        date: "2025-04-16"
      }
    ],
    averageRating: 4.5
  }
];

// Pre-defined ingredients for autocomplete
export const ingredients: Ingredient[] = [
  "Avocado", "Tomatoes", "Onions", "Garlic", "Pasta", "Eggs", 
  "Cheese", "Bacon", "Chicken", "Beef", "Rice", "Potatoes",
  "Carrots", "Spinach", "Lettuce", "Mushrooms", "Bell Peppers",
  "Olive Oil", "Butter", "Milk", "Flour", "Sugar", "Salt",
  "Lemon", "Lime", "Basil", "Cilantro", "Parsley"
];

// Function to get a recipe by ID
export function getRecipeById(id: number): RecipeMock | undefined {
  return recipes.find(recipe => recipe.id === id);
}

// Function to get recipes that match selected ingredients
export function getMatchingRecipes(selectedIngredients: string[]): RecipeMock[] {
  if (selectedIngredients.length === 0) return [];
  
  return recipes.filter(recipe => {
    // Check if at least one selected ingredient is in the recipe
    return selectedIngredients.some(ingredient => 
      recipe.ingredientList.some(recipeIngredient => 
        recipeIngredient.includes(ingredient.toLowerCase())
      )
    );
  });
}
