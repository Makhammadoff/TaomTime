import { 
  createContext, 
  ReactNode, 
  useContext, 
  useState, 
  useEffect 
} from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";

// Define default translations for each language
const defaultTranslations: Record<string, Record<string, string>> = {
  uz: {
    "app.name": "TaomTime",
    "home.title": "Taomlaringizni toping",
    "home.subtitle": "Mazali retseptlar va oshpazlik g'oyalari",
    "search.title": "Ingredientlar bo'yicha qidirish",
    "search.subtitle": "Mavjud ingredientlar asosida retseptlarni qidiring",
    "auth.login": "Tizimga kirish",
    "auth.register": "Ro'yxatdan o'tish",
    "auth.welcome": "Xush kelibsiz",
    "profile.title": "Profil",
    "recipe.ingredients": "Ingredientlar",
    "recipe.instructions": "Tayyorlash ketma-ketligi",
    "recipe.cooking_assistant": "Oshpazlik yordamchisi",
    "recipe.reviews": "Sharhlar",
    "recipe.leave_review": "Sharh qoldiring",
    "language": "Til",
  },
  en: {
    "app.name": "TaomTime",
    "home.title": "Find Your Recipes",
    "home.subtitle": "Delicious recipes and cooking ideas",
    "search.title": "Search by Ingredients",
    "search.subtitle": "Find recipes based on ingredients you have",
    "auth.login": "Login",
    "auth.register": "Register",
    "auth.welcome": "Welcome",
    "profile.title": "Profile",
    "recipe.ingredients": "Ingredients",
    "recipe.instructions": "Instructions",
    "recipe.cooking_assistant": "Cooking Assistant",
    "recipe.reviews": "Reviews",
    "recipe.leave_review": "Leave a Review",
    "language": "Language",
  },
  ru: {
    "app.name": "TaomTime",
    "home.title": "Найдите свои рецепты",
    "home.subtitle": "Вкусные рецепты и кулинарные идеи",
    "search.title": "Поиск по ингредиентам",
    "search.subtitle": "Найдите рецепты на основе имеющихся ингредиентов",
    "auth.login": "Вход",
    "auth.register": "Регистрация",
    "auth.welcome": "Добро пожаловать",
    "profile.title": "Профиль",
    "recipe.ingredients": "Ингредиенты",
    "recipe.instructions": "Инструкции",
    "recipe.cooking_assistant": "Кулинарный помощник",
    "recipe.reviews": "Отзывы",
    "recipe.leave_review": "Оставить отзыв",
    "language": "Язык",
  }
};

type TranslationsContextType = {
  t: (key: string, fallback?: string) => string;
  language: string;
  isLoading: boolean;
};

const TranslationsContext = createContext<TranslationsContextType>({
  t: (key: string, fallback?: string) => fallback || key,
  language: "uz",
  isLoading: false,
});

export function TranslationsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [language, setLanguage] = useState<string>("uz"); // Default language is Uzbek
  
  // When user changes, update the language
  useEffect(() => {
    if (user?.language) {
      setLanguage(user.language);
    }
  }, [user]);
  
  // Fetch translations from API
  const { data: translations, isLoading } = useQuery<Record<string, string>>({
    queryKey: ["/api/translations", language],
    queryFn: async () => {
      const response = await fetch(`/api/translations/${language}`);
      if (!response.ok) {
        throw new Error("Failed to fetch translations");
      }
      return response.json();
    },
    enabled: !!language, // Only fetch when language is available
  });
  
  // Translation function
  const t = (key: string, fallback?: string): string => {
    // First try to get from API translations
    if (translations && translations[key]) {
      return translations[key];
    }
    
    // Then try default translations
    if (defaultTranslations[language] && defaultTranslations[language][key]) {
      return defaultTranslations[language][key];
    }
    
    // Fall back to English
    if (language !== "en" && defaultTranslations["en"] && defaultTranslations["en"][key]) {
      return defaultTranslations["en"][key];
    }
    
    // Return fallback or key itself
    return fallback || key;
  };
  
  return (
    <TranslationsContext.Provider value={{ t, language, isLoading }}>
      {children}
    </TranslationsContext.Provider>
  );
}

export function useTranslations() {
  const context = useContext(TranslationsContext);
  if (!context) {
    throw new Error("useTranslations must be used within a TranslationsProvider");
  }
  return context;
}