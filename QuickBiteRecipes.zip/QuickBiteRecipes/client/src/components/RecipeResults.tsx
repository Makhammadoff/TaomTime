import { Recipe } from "@shared/schema";
import { Link } from "wouter";
import { capitalize } from "@/lib/utils";

interface RecipeResultsProps {
  recipes: Recipe[];
  selectedIngredients: string[];
}

export default function RecipeResults({ recipes, selectedIngredients }: RecipeResultsProps) {
  // Empty state when no recipes match
  if (selectedIngredients.length > 0 && recipes.length === 0) {
    return (
      <div>
        <h2 className="text-xl font-bold mb-4 font-heading">Matching Recipes</h2>
        <div className="bg-white rounded-xl p-8 text-center shadow-md">
          <i className="ri-restaurant-line text-5xl text-gray-300 mb-4"></i>
          <h3 className="text-xl font-medium mb-2">No recipes found</h3>
          <p className="text-gray-600">Try selecting different ingredients or fewer ingredients.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div>
      <h2 className="text-xl font-bold mb-4 font-heading">Matching Recipes</h2>
      
      {selectedIngredients.length === 0 ? (
        <div className="bg-white rounded-xl p-8 text-center shadow-md">
          <i className="ri-restaurant-line text-5xl text-gray-300 mb-4"></i>
          <h3 className="text-xl font-medium mb-2">Select ingredients to find recipes</h3>
          <p className="text-gray-600">Add ingredients from the sidebar to see matching recipes.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {recipes.map((recipe) => {
            // Find matching ingredients for highlighting
            const matchingIngredients = selectedIngredients.filter(ingredient => 
              recipe.ingredientList.some(recipeIngredient => 
                recipeIngredient.includes(ingredient.toLowerCase())
              )
            );
            
            return (
              <div key={recipe.id} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow flex">
                <div className="w-1/3">
                  <img 
                    src={recipe.image} 
                    alt={recipe.title} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="w-2/3 p-4">
                  <h3 className="font-bold text-lg mb-2 font-heading">{recipe.title}</h3>
                  <p className="text-sm text-gray-600 mb-3">{recipe.description}</p>
                  <div className="flex flex-wrap gap-1 mb-3">
                    {matchingIngredients.map((ingredient, index) => (
                      <span key={index} className="inline-block bg-primary/10 text-primary px-2 py-0.5 rounded-full text-xs">
                        {capitalize(ingredient)}
                      </span>
                    ))}
                  </div>
                  <Link 
                    href={`/recipe/${recipe.id}`}
                    className="text-primary hover:text-primary/80 font-semibold text-sm flex items-center mt-1"
                  >
                    View Recipe
                    <i className="ri-arrow-right-line ml-1"></i>
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
