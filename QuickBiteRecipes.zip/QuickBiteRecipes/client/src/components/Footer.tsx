import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-white py-6 border-t">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <Link href="/" className="text-xl font-bold text-primary font-heading flex items-center">
              <i className="ri-restaurant-2-line mr-2"></i>
              TaomTime
            </Link>
            <p className="text-sm text-gray-600 mt-1">Find delicious recipes with ingredients you have.</p>
          </div>
          <div className="flex space-x-4">
            <a href="#" className="text-gray-600 hover:text-primary transition-colors">
              <i className="ri-github-fill text-xl"></i>
            </a>
            <a href="#" className="text-gray-600 hover:text-primary transition-colors">
              <i className="ri-twitter-fill text-xl"></i>
            </a>
            <a href="#" className="text-gray-600 hover:text-primary transition-colors">
              <i className="ri-instagram-fill text-xl"></i>
            </a>
          </div>
        </div>
        <div className="text-center mt-6 text-sm text-gray-500">
          &copy; {new Date().getFullYear()} TaomTime. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
