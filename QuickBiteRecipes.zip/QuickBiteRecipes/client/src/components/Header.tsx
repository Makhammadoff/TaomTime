import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  User, 
  LogOut, 
  PlusCircle, 
  Globe, 
  ChevronDown,
  Home,
  Search
} from "lucide-react";
import { queryClient } from "@/lib/queryClient";

// Language options for the dropdown
const languages = [
  { code: "uz", name: "Uzbek" },
  { code: "en", name: "English" },
  { code: "ru", name: "Russian" }
];

export default function Header() {
  const [location] = useLocation();
  const { user, logoutMutation, updateLanguageMutation } = useAuth();

  // Get user initials for avatar
  const getUserInitials = () => {
    if (!user || !user.nickname) return "U";
    return user.nickname.substring(0, 2).toUpperCase();
  };

  // Get user points display text
  const getUserPoints = () => {
    if (!user) return "0";
    return user.points.toString();
  };

  // Handle language change
  const handleLanguageChange = async (language: string) => {
    if (user) {
      try {
        // Call the API to update the user's language
        const response = await fetch("/api/user/language", {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ language }),
          credentials: 'include'
        });
        
        if (!response.ok) {
          console.error("Failed to update language");
          return;
        }
        
        // Update the user data
        const updatedUser = await response.json();
        queryClient.setQueryData(["/api/user"], updatedUser);
        
        // Refresh the page to apply the language change
        window.location.reload();
      } catch (error) {
        console.error("Error updating language:", error);
      }
    } else {
      // For non-logged in users, store the preference in local storage
      localStorage.setItem("preferredLanguage", language);
      window.location.reload();
    }
  };

  // Get current language name
  const getCurrentLanguageName = () => {
    const currentLang = user?.language || "uz";
    return languages.find(lang => lang.code === currentLang)?.name || "Uzbek";
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex flex-col sm:flex-row justify-between items-center">
        <div className="flex items-center mb-4 sm:mb-0">
          <Link href="/" className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary font-heading flex items-center">
            <i className="ri-restaurant-2-line mr-2"></i>
            TaomTime
          </Link>
        </div>
        
        <nav className="flex items-center space-x-6">
          <ul className="flex space-x-6">
            <li>
              <Link 
                href="/" 
                className={`font-medium hover:text-primary transition-colors flex items-center ${location === '/' ? 'text-primary' : 'text-[#333333]'}`}
              >
                <Home className="w-4 h-4 mr-1" />
                Home
              </Link>
            </li>
            <li>
              <Link 
                href="/search" 
                className={`font-medium hover:text-primary transition-colors flex items-center ${location === '/search' ? 'text-primary' : 'text-[#333333]'}`}
              >
                <Search className="w-4 h-4 mr-1" />
                Search by Ingredients
              </Link>
            </li>
          </ul>

          {/* Language selector */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="flex items-center">
                <Globe className="h-4 w-4 mr-1" />
                <span className="hidden md:inline">{getCurrentLanguageName()}</span>
                <ChevronDown className="h-3 w-3 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Language</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {languages.map(lang => (
                <DropdownMenuItem 
                  key={lang.code}
                  onClick={() => handleLanguageChange(lang.code)}
                  className={user?.language === lang.code ? "bg-primary/10" : ""}
                >
                  {lang.name}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User profile or login button */}
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="flex items-center">
                  <Avatar className="h-8 w-8 mr-2">
                    <AvatarFallback className="bg-primary/20 text-primary text-sm">
                      {getUserInitials()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col items-start text-left">
                    <span className="font-medium text-sm">{user.nickname}</span>
                    <span className="text-xs text-muted-foreground">{getUserPoints()} points</span>
                  </div>
                  <ChevronDown className="h-3 w-3 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile" className="cursor-pointer flex w-full">
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/create-recipe" className="cursor-pointer flex w-full">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    <span>Add Recipe</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => logoutMutation.mutate()}
                  disabled={logoutMutation.isPending}
                  className="text-destructive focus:text-destructive"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>{logoutMutation.isPending ? "Logging out..." : "Logout"}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button asChild size="sm" className="ml-2">
              <Link href="/auth">
                Login / Sign Up
              </Link>
            </Button>
          )}
        </nav>
      </div>
    </header>
  );
}
