import { useState } from "react";

interface StarRatingProps {
  rating: number;
  maxRating?: number;
  size?: "sm" | "md" | "lg";
  interactive?: boolean;
  onRatingChange?: (rating: number) => void;
}

export default function StarRating({
  rating,
  maxRating = 5,
  size = "md",
  interactive = false,
  onRatingChange
}: StarRatingProps) {
  const [hoverRating, setHoverRating] = useState(0);
  
  // Size classes for stars
  const sizeClasses = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-2xl"
  };
  
  // Handle clicking a star when interactive
  const handleStarClick = (starRating: number) => {
    if (interactive && onRatingChange) {
      onRatingChange(starRating);
    }
  };

  return (
    <div className="flex items-center">
      {[...Array(maxRating)].map((_, index) => {
        const starValue = index + 1;
        const filled = interactive 
          ? starValue <= (hoverRating || rating)
          : starValue <= rating;
        const halfFilled = !filled && starValue <= rating + 0.5;
        
        return (
          <span
            key={index}
            className={`${sizeClasses[size]} ${interactive ? 'cursor-pointer' : ''}`}
            onClick={() => handleStarClick(starValue)}
            onMouseEnter={() => interactive && setHoverRating(starValue)}
            onMouseLeave={() => interactive && setHoverRating(0)}
          >
            {filled ? (
              <i className="ri-star-fill text-yellow-400"></i>
            ) : halfFilled ? (
              <i className="ri-star-half-fill text-yellow-400"></i>
            ) : (
              <i className="ri-star-line text-yellow-400"></i>
            )}
          </span>
        );
      })}
      
      {/* Display the numeric rating if desired */}
      {rating > 0 && (
        <span className="ml-2 text-sm text-gray-600">
          {rating.toFixed(1)}
        </span>
      )}
    </div>
  );
}