import { capitalize } from "@/lib/utils";

interface SelectedIngredientsProps {
  selectedIngredients: string[];
  onRemoveIngredient: (ingredient: string) => void;
  onFindRecipes: () => void;
}

export default function SelectedIngredients({ 
  selectedIngredients, 
  onRemoveIngredient, 
  onFindRecipes 
}: SelectedIngredientsProps) {
  return (
    <div>
      <h3 className="font-medium mb-3">Selected ingredients:</h3>
      <div className="flex flex-wrap gap-2 mb-4">
        {selectedIngredients.length > 0 ? (
          selectedIngredients.map((ingredient, index) => (
            <span key={index} className="inline-flex items-center bg-secondary/10 px-3 py-1 rounded-full text-secondary">
              <span>{capitalize(ingredient)}</span>
              <button 
                className="ml-1 text-secondary hover:text-secondary/80"
                onClick={() => onRemoveIngredient(ingredient)}
                aria-label={`Remove ${ingredient}`}
              >
                <i className="ri-close-line"></i>
              </button>
            </span>
          ))
        ) : (
          <p className="text-gray-500 text-sm">No ingredients selected yet</p>
        )}
      </div>
      
      <button 
        className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 px-6 rounded-lg shadow-md transition-all font-heading flex items-center justify-center"
        onClick={onFindRecipes}
        disabled={selectedIngredients.length === 0}
      >
        <i className="ri-restaurant-line mr-2"></i>
        Find Recipes
      </button>
    </div>
  );
}
