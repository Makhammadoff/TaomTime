import { useState, useRef, useEffect } from "react";
import { ingredients } from "@/lib/recipes";
import { capitalize } from "@/lib/utils";

interface IngredientSearchProps {
  selectedIngredients: string[];
  onAddIngredient: (ingredient: string) => void;
}

export default function IngredientSearch({ selectedIngredients, onAddIngredient }: IngredientSearchProps) {
  const [searchValue, setSearchValue] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filteredIngredients, setFilteredIngredients] = useState<string[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Filter ingredients based on search value and selected ingredients
    if (searchValue.trim().length > 0) {
      const filtered = ingredients.filter(
        (ingredient) => 
          ingredient.toLowerCase().includes(searchValue.toLowerCase()) && 
          !selectedIngredients.map(ing => ing.toLowerCase()).includes(ingredient.toLowerCase())
      );
      setFilteredIngredients(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setShowSuggestions(false);
    }
  }, [searchValue, selectedIngredients]);

  useEffect(() => {
    // Hide suggestions when clicking outside
    function handleClickOutside(e: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleIngredientSelect = (ingredient: string) => {
    onAddIngredient(ingredient);
    setSearchValue("");
    setShowSuggestions(false);
  };

  return (
    <div className="mb-6" ref={searchRef}>
      <label htmlFor="ingredient-search" className="block mb-2 font-medium">
        Search ingredients:
      </label>
      <div className="relative">
        <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
        <input 
          type="text" 
          id="ingredient-search" 
          className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
          placeholder="Type an ingredient..."
          value={searchValue}
          onChange={(e) => setSearchValue(e.target.value)}
          onFocus={() => {
            if (searchValue.trim().length > 0 && filteredIngredients.length > 0) {
              setShowSuggestions(true);
            }
          }}
        />
      </div>
      
      {/* Ingredient suggestions */}
      {showSuggestions && (
        <div className="mt-2 bg-white rounded-lg shadow-lg border border-gray-100 max-h-60 overflow-y-auto">
          {filteredIngredients.map((ingredient, index) => (
            <button 
              key={index}
              className="w-full text-left px-4 py-2 hover:bg-gray-100 transition-colors flex items-center"
              onClick={() => handleIngredientSelect(ingredient)}
            >
              <i className="ri-add-line mr-2 text-primary"></i>
              <span>{ingredient}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
