import { Link } from "wouter";
import { RecipeMock } from "@shared/schema";
import StarRating from "./StarRating";

interface RecipeCardProps {
  recipe: RecipeMock;
}

export default function RecipeCard({ recipe }: RecipeCardProps) {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={recipe.image} 
          alt={recipe.title} 
          className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-0 right-0 bg-primary text-white text-xs font-bold px-2 py-1 m-2 rounded">
          {recipe.time}
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-xl mb-2 font-heading">{recipe.title}</h3>
        <div className="mb-3">
          <StarRating rating={recipe.averageRating || 0} size="sm" />
          <span className="text-xs text-gray-500 ml-1">
            ({recipe.ratings.length} {recipe.ratings.length === 1 ? 'review' : 'reviews'})
          </span>
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          {recipe.tags.map((tag, index) => (
            <span key={index} className="inline-block bg-secondary/10 text-secondary px-2 py-1 rounded text-xs">
              {tag}
            </span>
          ))}
        </div>
        <Link 
          href={`/recipe/${recipe.id}`} 
          className="text-primary hover:text-primary/80 font-semibold text-sm flex items-center mt-2"
        >
          View Recipe
          <i className="ri-arrow-right-line ml-1"></i>
        </Link>
      </div>
    </div>
  );
}
