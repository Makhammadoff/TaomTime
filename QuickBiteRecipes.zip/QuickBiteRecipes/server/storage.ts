import { db } from "./db";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";
import { eq, and, asc, desc, count, sql } from "drizzle-orm";
import { 
  users, type User, type InsertUser, 
  recipes, type Recipe, type RecipeMock, insertRecipeSchema, 
  ratings, type Rating, type RatingMock, insertRatingSchema,
  translationKeys, translations
} from "@shared/schema";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserRatings(userId: number): Promise<Rating[]>;
  getUserRecipes(userId: number): Promise<Recipe[]>;
  updateUserPoints(userId: number, points: number): Promise<User | undefined>;
  updateUserLanguage(userId: number, language: string): Promise<User | undefined>;
  
  // Recipe operations
  getRecipe(id: number): Promise<Recipe | undefined>;
  getRecipes(language: string, limit?: number, offset?: number): Promise<Recipe[]>;
  getPopularRecipes(language: string, limit?: number): Promise<Recipe[]>;
  createRecipe(recipe: typeof insertRecipeSchema._type): Promise<Recipe>;
  updateRecipe(id: number, recipe: Partial<typeof insertRecipeSchema._type>): Promise<Recipe | undefined>;
  deleteRecipe(id: number): Promise<boolean>;
  getRecipesByIngredients(ingredients: string[], language: string): Promise<Recipe[]>;
  
  // Rating operations
  getRatingsForRecipe(recipeId: number): Promise<Rating[]>;
  createRating(rating: typeof insertRatingSchema._type): Promise<Rating>;
  updateRating(id: number, rating: Partial<typeof insertRatingSchema._type>): Promise<Rating | undefined>;
  deleteRating(id: number): Promise<boolean>;
  getUserRatingsForRecipe(userId: number, recipeId: number): Promise<Rating[]>;
  
  // Translation operations
  getTranslations(language: string): Promise<Record<string, string>>;
  
  // Session store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async getUserRatings(userId: number): Promise<Rating[]> {
    return db.select().from(ratings).where(eq(ratings.userId, userId));
  }

  async getUserRecipes(userId: number): Promise<Recipe[]> {
    return db.select().from(recipes).where(eq(recipes.userId, userId));
  }

  async updateUserPoints(userId: number, points: number): Promise<User | undefined> {
    const result = await db
      .update(users)
      .set({ points })
      .where(eq(users.id, userId))
      .returning();
    return result[0];
  }
  
  async updateUserLanguage(userId: number, language: string): Promise<User | undefined> {
    const result = await db
      .update(users)
      .set({ language })
      .where(eq(users.id, userId))
      .returning();
    return result[0];
  }

  // Recipe operations
  async getRecipe(id: number): Promise<Recipe | undefined> {
    const result = await db.select().from(recipes).where(eq(recipes.id, id));
    return result[0];
  }

  async getRecipes(language: string, limit = 20, offset = 0): Promise<Recipe[]> {
    return db
      .select()
      .from(recipes)
      .where(eq(recipes.language, language))
      .limit(limit)
      .offset(offset)
      .orderBy(desc(recipes.createdAt));
  }

  async getPopularRecipes(language: string, limit = 10): Promise<Recipe[]> {
    return db
      .select()
      .from(recipes)
      .where(eq(recipes.language, language))
      .orderBy(desc(recipes.averageRating))
      .limit(limit);
  }

  async createRecipe(recipe: typeof insertRecipeSchema._type): Promise<Recipe> {
    const result = await db.insert(recipes).values(recipe).returning();
    return result[0];
  }

  async updateRecipe(id: number, recipe: Partial<typeof insertRecipeSchema._type>): Promise<Recipe | undefined> {
    const result = await db
      .update(recipes)
      .set(recipe)
      .where(eq(recipes.id, id))
      .returning();
    return result[0];
  }

  async deleteRecipe(id: number): Promise<boolean> {
    const result = await db.delete(recipes).where(eq(recipes.id, id)).returning();
    return result.length > 0;
  }

  async getRecipesByIngredients(ingredients: string[], language: string): Promise<Recipe[]> {
    // This is a simple implementation that finds recipes with any of the ingredients
    // A more advanced implementation would use full-text search or array_overlap
    const result = await db.execute(sql`
      SELECT * FROM recipes 
      WHERE language = ${language} 
      AND (${ingredients.map(i => `'${i}' = ANY(ingredient_list)`).join(' OR ')})
      ORDER BY created_at DESC
    `);
    return result.rows as Recipe[];
  }

  // Rating operations
  async getRatingsForRecipe(recipeId: number): Promise<Rating[]> {
    return db.select().from(ratings).where(eq(ratings.recipeId, recipeId));
  }

  async createRating(rating: typeof insertRatingSchema._type): Promise<Rating> {
    const result = await db.insert(ratings).values(rating).returning();
    
    // Update the average rating for the recipe
    await this.updateAverageRating(rating.recipeId);
    
    // Update user points (+10 for each rating)
    const user = await this.getUser(rating.userId);
    if (user) {
      await this.updateUserPoints(user.id, user.points + 10);
    }
    
    return result[0];
  }

  async updateRating(id: number, rating: Partial<typeof insertRatingSchema._type>): Promise<Rating | undefined> {
    const result = await db
      .update(ratings)
      .set(rating)
      .where(eq(ratings.id, id))
      .returning();
    
    if (result.length > 0 && rating.rating) {
      await this.updateAverageRating(result[0].recipeId);
    }
    
    return result[0];
  }

  async deleteRating(id: number): Promise<boolean> {
    const findRating = await db.select().from(ratings).where(eq(ratings.id, id));
    if (findRating.length === 0) return false;
    
    const recipeId = findRating[0].recipeId;
    const result = await db.delete(ratings).where(eq(ratings.id, id)).returning();
    
    if (result.length > 0) {
      await this.updateAverageRating(recipeId);
    }
    
    return result.length > 0;
  }

  async getUserRatingsForRecipe(userId: number, recipeId: number): Promise<Rating[]> {
    return db
      .select()
      .from(ratings)
      .where(and(eq(ratings.userId, userId), eq(ratings.recipeId, recipeId)));
  }

  // Helper method to update the average rating for a recipe
  private async updateAverageRating(recipeId: number): Promise<void> {
    const result = await db.execute(sql`
      SELECT AVG(rating) as avg_rating FROM ratings WHERE recipe_id = ${recipeId}
    `);
    
    const avgRating = result.rows[0]?.avg_rating || 0;
    
    await db
      .update(recipes)
      .set({ averageRating: Math.round(avgRating) })
      .where(eq(recipes.id, recipeId));
  }

  // Translation operations
  async getTranslations(language: string): Promise<Record<string, string>> {
    const result = await db.execute(sql`
      SELECT tk.key, t.value
      FROM translation_keys tk
      JOIN translations t ON tk.id = t.key_id
      WHERE t.language = ${language}
    `);
    
    const translations: Record<string, string> = {};
    for (const row of result.rows) {
      translations[row.key] = row.value;
    }
    
    return translations;
  }
}

export const storage = new DatabaseStorage();
