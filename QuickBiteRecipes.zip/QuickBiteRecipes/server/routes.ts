import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import OpenAI from "openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication and user routes
  setupAuth(app);
  
  // User language update route
  app.put("/api/user/language", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const { language } = req.body;
      
      if (!language || !["uz", "en", "ru"].includes(language)) {
        return res.status(400).json({ error: "Invalid language" });
      }
      
      const updatedUser = await storage.updateUserLanguage(req.user.id, language);
      
      if (!updatedUser) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user language:", error);
      res.status(500).json({ error: "Failed to update user language" });
    }
  });
  
  // Recipe routes
  app.get("/api/recipes", async (req, res, next) => {
    try {
      const language = req.query.language as string || "uz";
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const recipes = await storage.getRecipes(language, limit, offset);
      res.json(recipes);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/recipes/popular", async (req, res, next) => {
    try {
      const language = req.query.language as string || "uz";
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      
      const recipes = await storage.getPopularRecipes(language, limit);
      res.json(recipes);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/recipes/:id", async (req, res, next) => {
    try {
      const recipeId = parseInt(req.params.id);
      const recipe = await storage.getRecipe(recipeId);
      
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      
      // Get ratings for this recipe
      const ratings = await storage.getRatingsForRecipe(recipeId);
      
      // Combine recipe with ratings
      res.json({
        ...recipe,
        ratings
      });
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/recipes", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "You must be logged in to create recipes" });
    }
    
    try {
      const recipeData = {
        ...req.body,
        userId: req.user.id
      };
      
      const recipe = await storage.createRecipe(recipeData);
      
      // Add points to the user for creating a recipe (+50 points)
      await storage.updateUserPoints(req.user.id, req.user.points + 50);
      
      res.status(201).json(recipe);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/recipes/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "You must be logged in to update recipes" });
    }
    
    try {
      const recipeId = parseInt(req.params.id);
      const recipe = await storage.getRecipe(recipeId);
      
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      
      if (recipe.userId !== req.user.id) {
        return res.status(403).json({ error: "You can only edit your own recipes" });
      }
      
      const updatedRecipe = await storage.updateRecipe(recipeId, req.body);
      res.json(updatedRecipe);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/recipes/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "You must be logged in to delete recipes" });
    }
    
    try {
      const recipeId = parseInt(req.params.id);
      const recipe = await storage.getRecipe(recipeId);
      
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      
      if (recipe.userId !== req.user.id) {
        return res.status(403).json({ error: "You can only delete your own recipes" });
      }
      
      await storage.deleteRecipe(recipeId);
      res.status(204).end();
    } catch (error) {
      next(error);
    }
  });
  
  // Search recipes by ingredients
  app.post("/api/recipes/search", async (req, res, next) => {
    try {
      const { ingredients, language = "uz" } = req.body;
      
      if (!ingredients || !Array.isArray(ingredients) || ingredients.length === 0) {
        return res.status(400).json({ error: "Ingredients array is required" });
      }
      
      const recipes = await storage.getRecipesByIngredients(ingredients, language);
      res.json(recipes);
    } catch (error) {
      next(error);
    }
  });
  
  // Rating routes
  app.get("/api/recipes/:id/ratings", async (req, res, next) => {
    try {
      const recipeId = parseInt(req.params.id);
      const ratings = await storage.getRatingsForRecipe(recipeId);
      res.json(ratings);
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/recipes/:id/ratings", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "You must be logged in to rate recipes" });
    }
    
    try {
      const recipeId = parseInt(req.params.id);
      const recipe = await storage.getRecipe(recipeId);
      
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      
      // Check if user already left 2 ratings for this recipe
      const userRatings = await storage.getUserRatingsForRecipe(req.user.id, recipeId);
      
      if (userRatings.length >= 2) {
        return res.status(400).json({ error: "You can only leave up to 2 ratings per recipe" });
      }
      
      const ratingData = {
        ...req.body,
        recipeId,
        userId: req.user.id
      };
      
      const rating = await storage.createRating(ratingData);
      res.status(201).json(rating);
    } catch (error) {
      next(error);
    }
  });
  
  // Direct rating submission route
  app.post("/api/ratings", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "You must be logged in to rate recipes" });
    }
    
    try {
      const { recipeId, rating, comment } = req.body;
      
      if (!recipeId) {
        return res.status(400).json({ error: "Recipe ID is required" });
      }
      
      if (!rating) {
        return res.status(400).json({ error: "Rating is required" });
      }
      
      const recipe = await storage.getRecipe(recipeId);
      
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      
      // Check if user already left 2 ratings for this recipe
      const userRatings = await storage.getUserRatingsForRecipe(req.user.id, recipeId);
      
      if (userRatings.length >= 2) {
        return res.status(400).json({ error: "You can only leave up to 2 ratings per recipe" });
      }
      
      const ratingData = {
        recipeId,
        userId: req.user.id,
        rating,
        comment: comment || ""
      };
      
      const newRating = await storage.createRating(ratingData);
      
      // Add points to the recipe owner (if it's not the user's own recipe)
      if (recipe.userId !== req.user.id) {
        const recipeOwner = await storage.getUser(recipe.userId);
        if (recipeOwner) {
          // Add 10 points for every rating received
          await storage.updateUserPoints(recipe.userId, recipeOwner.points + 10);
        }
      }
      
      res.status(200).json(newRating);
    } catch (error) {
      console.error("Error creating rating:", error);
      res.status(500).json({ error: "Failed to create rating" });
    }
  });

  // Get user ratings for a recipe
  app.get("/api/ratings/user/:recipeId", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "You must be logged in to view your ratings" });
    }
    
    try {
      const recipeId = parseInt(req.params.recipeId);
      const userRatings = await storage.getUserRatingsForRecipe(req.user.id, recipeId);
      res.json(userRatings);
    } catch (error) {
      console.error("Error fetching user ratings:", error);
      res.status(500).json({ error: "Failed to fetch ratings" });
    }
  });
  
  // Translation routes
  app.get("/api/translations/:language", async (req, res, next) => {
    try {
      const language = req.params.language;
      
      if (!["uz", "en", "ru"].includes(language)) {
        return res.status(400).json({ error: "Invalid language" });
      }
      
      const translations = await storage.getTranslations(language);
      res.json(translations);
    } catch (error) {
      next(error);
    }
  });

  // AI Cooking Assistant API
  app.post("/api/ai/cooking-assistant", async (req, res, next) => {
    try {
      const { question, recipeId } = req.body;
      
      if (!question) {
        return res.status(400).json({ error: "Question is required" });
      }
      
      if (!recipeId) {
        return res.status(400).json({ error: "Recipe ID is required" });
      }

      // Get the recipe data
      const recipe = await storage.getRecipe(recipeId);
      
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }

      // Check if OpenAI API key is available
      if (!process.env.OPENAI_API_KEY) {
        return res.status(503).json({ 
          error: "AI Cooking Assistant is not available",
          message: "The OpenAI API key is not configured"
        });
      }

      // Initialize OpenAI client
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

      // Generate system prompt with recipe details
      const systemPrompt = `
You are a helpful cooking assistant for the TaomTime recipe app. 
Your job is to answer questions about cooking techniques, ingredient substitutions, and recipe modifications.

Here are the details of the recipe the user is asking about:

Recipe: ${recipe.title}
Ingredients: ${recipe.ingredients.join(', ')}
Instructions: ${recipe.instructions.join(' ')}

You must always try to be as helpful as possible. Answer the user's question about this recipe in a concise and practical way.

Important:
1. If the question relates directly to information provided in the recipe, use that information to answer.
2. If the question asks about a cooking technique or substitution not directly mentioned in the recipe, provide a helpful answer based on general cooking knowledge.
3. For ingredient substitutions, explain why the substitution works and how it might change the flavor or texture.
4. For cooking techniques, explain them clearly even if they're not in the recipe.
5. Never say "I don't know" - instead, provide the best cooking advice you can based on the context and general cooking principles.
6. Always try to help the user successfully cook the recipe, even if the information isn't explicitly in the recipe details.
7. Answer in the user's language if you can detect it.

Remember you are a cooking expert - confidently share your knowledge about cooking techniques, ingredient properties, and recipe adaptations.
`;

      // Call OpenAI API
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: question }
        ],
        max_tokens: 300,
        temperature: 0.7,
      });

      // Return the AI response
      const answer = response.choices[0].message.content;
      res.json({ answer });
    } catch (error) {
      console.error("OpenAI API error:", error);
      res.status(500).json({ 
        error: "Failed to get response from AI Cooking Assistant",
        message: error.message
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
