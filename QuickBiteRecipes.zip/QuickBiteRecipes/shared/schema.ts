import { pgTable, text, integer, serial, boolean, timestamp, json, primaryKey, uniqueIndex, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users Table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  nickname: text("nickname").notNull(),
  points: integer("points").default(0).notNull(),
  profileImage: text("profile_image"),
  language: text("language").default("uz").notNull(), // 'uz', 'en', 'ru'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ many }) => ({
  recipes: many(recipes),
  ratings: many(ratings),
}));

// Recipes Table
export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  time: text("time").notNull(),
  servings: integer("servings").notNull(),
  calories: integer("calories").notNull(),
  tags: text("tags").array().notNull(),
  ingredients: text("ingredients").array().notNull(),
  ingredientList: text("ingredient_list").array().notNull(),
  instructions: text("instructions").array().notNull(),
  language: text("language").default("uz").notNull(), // 'uz', 'en', 'ru'
  averageRating: integer("average_rating").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const recipesRelations = relations(recipes, ({ one, many }) => ({
  user: one(users, {
    fields: [recipes.userId],
    references: [users.id],
  }),
  ratings: many(ratings),
}));

// Ratings Table
export const ratings = pgTable("ratings", {
  id: serial("id").primaryKey(),
  recipeId: integer("recipe_id").notNull().references(() => recipes.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  rating: integer("rating").notNull(), // 1-5
  comment: text("comment"),
  date: timestamp("date").defaultNow().notNull(),
}, (table) => {
  return {
    // Each user can only rate a recipe twice
    userRecipeIdx: uniqueIndex("user_recipe_idx").on(table.userId, table.recipeId),
  };
});

export const ratingsRelations = relations(ratings, ({ one }) => ({
  recipe: one(recipes, {
    fields: [ratings.recipeId],
    references: [recipes.id],
  }),
  user: one(users, {
    fields: [ratings.userId],
    references: [users.id],
  }),
}));

// Translation Keys Table (for localization)
export const translationKeys = pgTable("translation_keys", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
});

// Translations Table
export const translations = pgTable("translations", {
  keyId: integer("key_id").notNull().references(() => translationKeys.id, { onDelete: "cascade" }),
  language: text("language").notNull(), // 'uz', 'en', 'ru'
  value: text("value").notNull(),
}, (table) => {
  return {
    pk: primaryKey({ columns: [table.keyId, table.language] }),
  }
});

export const translationsRelations = relations(translations, ({ one }) => ({
  key: one(translationKeys, {
    fields: [translations.keyId],
    references: [translationKeys.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  nickname: true,
  language: true,
  profileImage: true,
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
  averageRating: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRatingSchema = createInsertSchema(ratings).omit({
  id: true,
  date: true,
});

// Type definitions
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Recipe = typeof recipes.$inferSelect;
export type Rating = typeof ratings.$inferSelect;

// Temporary type for our mock data
export type RecipeMock = {
  id: number;
  title: string;
  image: string;
  description: string;
  time: string;
  servings: number;
  calories: number;
  tags: string[];
  ingredients: string[];
  ingredientList: string[];
  instructions: string[];
  ratings: RatingMock[];
  averageRating?: number;
};

export type RatingMock = {
  id: number;
  recipeId: number;
  userId?: number;
  userName: string;
  rating: number; // 1-5
  comment?: string;
  date: string;
};

// Ingredient type definition
export type Ingredient = string;
